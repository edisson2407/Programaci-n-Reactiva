import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import rx.lang.scala.Observable

object MiApp extends App {

  // Crear un flujo de datos reactivo con un Future

  val futureData: Future[Int] = Future {

    // Simular un proceso asíncrono
    Thread.sleep(1000)
    42
  }

  // Convertir el Future en un flujo reactivo (Observable)

  val reactiveData = Observable.from(futureData)

  // Aplicar un operador de mapa para duplicar el valor

  val doubledData = reactiveData.map(value => value * 2)

  // Suscribirse para recibir los valores del flujo

  doubledData.subscribe(
    onNext = value => println(s"Valor duplicado: $value"),
    onError = error => println(s"Error: $error"),
    onCompleted = () => println("Flujo completado")
  )

  // Esperar a que el ejemplo termine
  Thread.sleep(2000)
}
